<?php

return [
    '2018-01-29' => [
        'uz-cyrillic' => 'add new language : Uzbek cyrillic',
        'yz-latin'    => 'add new language : Uzbek latin',
    ],
    '2018-01-23' => [
        'lv' => 'fix rename validation file',
        'pl' => 'validation.ipv4 and validation.ipv6 updated',
    ],
    '2018-01-19' => [
        'ug' => 'add new language : Uyghur',
    ],
    '2018-01-10' => [
        'lv' => 'add new language : Latvia',
    ],
];
