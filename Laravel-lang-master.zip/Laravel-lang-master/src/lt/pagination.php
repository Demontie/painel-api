<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Puslapiavimo kalbos eilutės
    |--------------------------------------------------------------------------
    |
    | Šios kalbos eilutės yra naudojamas puslapiavimo bibliotekos kurti
    | paprastas puslapiavimo nuorodas. Jūs galite laisvai keisti jas
    | į bet kokias kitas labiau tinkančias Jūsų programai.
    |
    */

    'previous' => '&laquo; Ankstesnis',
    'next'     => 'Sekantis &raquo;',
];
